class Demo extends Component{
	render(){
		return <div className="maindiv_style">
			<h1> Hello {this.props.name} </h1>
			<p> react native coding...</p>
		</div>
	}
